# src\models\models.py

from sqlmodel import SQLModel, Field, Column, PrimaryKeyConstraint, ForeignKey
import sqlalchemy.dialects.postgresql as pg
from typing import Optional
from sqlalchemy import CheckConstraint

class Model(SQLModel, table=True):
    """
    Represents a model in the database.
    """
    __tablename__ = 'models_test'

    model_id: int = Field(default=None, primary_key=True)
    project_id: int = Field(sa_column=Column(pg.INTEGER, nullable=False))
    # project_id: int = Field(sa_column=Column(pg.INTEGER, ForeignKey("projects.project_id", ondelete="CASCADE"), nullable=False))
    name: str = Field(sa_column=Column(pg.VARCHAR, nullable=False))
    version: str = Field(sa_column=Column(pg.VARCHAR, nullable=False))

    def __repr__(self) -> str:
        return f"Model(model_id={self.model_id}, name='{self.name}', version='{self.version}')"
    

# class Categoria(SQLModel, table=True):
#     """
#     Representa las clasificaciones de correo electrónico en la base de datos.
#     """
#     __tablename__ = 'test_creaciom'

#     message_id: str = Field(sa_column=Column(pg.VARCHAR(255)))
#     conversation_id: str = Field(sa_column=Column(pg.VARCHAR(255)))
#     buzon: str = Field(sa_column=Column(pg.VARCHAR(255), default=None))
#     cat1: str = Field(sa_column=Column(pg.VARCHAR(100), default=None))
#     cat2: Optional[str] = Field(sa_column=Column(pg.VARCHAR(100), default=None, nullable=True))
#     cat3: Optional[str] = Field(sa_column=Column(pg.VARCHAR(100), default=None, nullable=True))
#     categorized: bool = Field(sa_column=Column(pg.BOOLEAN, default=False))
#     processed_adjuntos: bool = Field(sa_column=Column(pg.BOOLEAN, default=False))
#     version: int = Field(sa_column=Column(pg.INTEGER, default=1))
#     categorized_1: str = Field(sa_column=Column(pg.VARCHAR(255), nullable=True))
#     categorized_2: str = Field(sa_column=Column(pg.VARCHAR(255), nullable=True))
#     categorized_3: str = Field(sa_column=Column(pg.VARCHAR(255), nullable=True))
#     categorized_validated: bool = Field(sa_column=Column(pg.BOOLEAN, default=False))

#     __table_args__ = (
#         PrimaryKeyConstraint('message_id', 'conversation_id', 'version'),
#     )
