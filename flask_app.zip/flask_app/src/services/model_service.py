# services/model_service.py

from sqlmodel import select
from sqlalchemy.orm import Session
from flask import abort
from http import HTTPStatus
try:
    from src.models.models import Model
except:
    from models.models import Model

class ModelService:
    def __init__(self, session: Session):
        self.session = session

    def get_all_models(self):
        statement = select(Model).order_by(Model.model_id)
        models = self.session.execute(statement).scalars().all()

        if not models:
            abort(HTTPStatus.NOT_FOUND, description="No models found.")

        return [
            {
                "model_id": model.model_id,
                "project_id": model.project_id,
                "name": model.name,
                "version": model.version
            }
            for model in models
        ]

