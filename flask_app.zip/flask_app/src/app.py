# src/app.py

from flask import Flask
from flask_smorest import Api
try:
    from src.core.manager_db import init_db
except:
    from core.manager_db import init_db

def create_app():
    app = Flask(__name__)

    app.config["PROPAGATE_EXCEPTIONS"] = True
    app.config["API_TITLE"] = "API de Modelos"
    app.config["API_VERSION"] = "v1"
    app.config["OPENAPI_VERSION"] = "3.0.3"
    app.config["OPENAPI_URL_PREFIX"] = "/"
    app.config["OPENAPI_SWAGGER_UI_PATH"] = "/docs"
    app.config["OPENAPI_SWAGGER_UI_URL"] = "https://cdn.jsdelivr.net/npm/swagger-ui-dist/"

    api = Api(app)

    init_db()

    # ─────────────────────────────────────────────────────────
    # Eliminamos/Comentamos los hooks para que NO abra sesión 
    # de forma global en todas las peticiones.
    # ─────────────────────────────────────────────────────────
    # @app.before_request
    # def before_request():
    #     request.db = get_session()

    # @app.teardown_request
    # def teardown_request(exception=None):
    #     db = getattr(request, "db", None)
    #     if db:
    #         db.close()

    try:
        from src.routes.models_routes import blp as models_blp
    except:
        from routes.models_routes import blp as models_blp

    api.register_blueprint(models_blp)

    return app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)
