# routes/models_routes.py

from flask.views import MethodView
from flask_smorest import Blueprint
from flask import request
try:
    from src.services.model_service import ModelService
    from src.core.manager_db import require_db_session
except:
    from services.model_service import ModelService
    from core.manager_db import require_db_session
    
blp = Blueprint("models", "models", url_prefix="/models", description="Operaciones con modelos")

@blp.route("/")
class ModelList(MethodView):
    @blp.response(200)
    @require_db_session
    def get(self, db):
        """Listar todos los modelos"""
        models = ModelService(db).get_all_models()
        return models



